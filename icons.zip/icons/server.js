// server.js
const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors()); // 웹사이트에서 API 호출 허용
app.use(express.json());

let usageData = {};  // { domain: totalTimeMillis }

app.post('/api/usage', (req, res) => {
  const { domain, timeSpent } = req.body;
  if (!domain || !timeSpent) {
    return res.status(400).json({ error: 'domain and timeSpent required' });
  }
  usageData[domain] = (usageData[domain] || 0) + timeSpent;
  res.json({ success: true, usageData });
});

app.get('/api/usage', (req, res) => {
  res.json(usageData);
});

app.listen(3000, () => console.log('서버 실행 중: http://localhost:3000'));
