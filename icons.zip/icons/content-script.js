// chrome.storage.local에서 저장된 사용 시간 정보 불러오기
chrome.storage.local.get("usageData", (result) => {
  const usageData = result.usageData || {};

  // 데이터가 없으면 메시지 출력
  if (Object.keys(usageData).length === 0) {
    showMessage("⏱ 아직 저장된 사용 시간 데이터가 없습니다.");
    return;
  }

  // 컨테이너 요소 생성
  const container = document.createElement("div");
  container.style.position = "relative";
  container.style.backgroundColor = "#f0f8ff";
  container.style.border = "1px solid #ccc";
  container.style.padding = "16px";
  container.style.margin = "16px";
  container.style.borderRadius = "8px";
  container.style.fontFamily = "sans-serif";
  container.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
  container.style.maxWidth = "600px";

  const title = document.createElement("h2");
  title.textContent = "💻 디지털 웰빙 사용 시간 요약";
  container.appendChild(title);

  // 시간 포맷 함수 (밀리초 → 시:분:초)
  function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;
    return `${h}시간 ${m}분 ${s}초`;
  }

  // 각 도메인별 사용 시간 표시
  Object.entries(usageData).forEach(([domain, timeMs]) => {
    const p = document.createElement("p");
    p.textContent = `${domain} ➜ ${formatTime(timeMs)}`;
    p.style.margin = "6px 0";
    container.appendChild(p);
  });

  // body 최상단에 삽입
  document.body.prepend(container);
});

// 메시지 출력 함수
function showMessage(msg) {
  const div = document.createElement("div");
  div.textContent = msg;
  div.style.backgroundColor = "#ffeeee";
  div.style.color = "#aa0000";
  div.style.padding = "12px";
  div.style.margin = "16px";
  div.style.borderRadius = "6px";
  div.style.fontWeight = "bold";
  div.style.fontFamily = "sans-serif";
  document.body.prepend(div);
}
