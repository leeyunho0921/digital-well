let activeTabId = null;
let activeDomain = null;
let startTime = null;
let usageData = {};

// URL에서 도메인만 추출
function extractDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return null;
  }
}

// 저장된 사용시간 데이터를 불러오기
function loadUsageData(callback) {
  chrome.storage.local.get({ usageData: {} }, (result) => {
    usageData = result.usageData || {};
    callback();
  });
}

// 사용시간 기록 후 저장
function recordTime() {
  if (activeDomain && startTime) {
    const elapsed = Date.now() - startTime;
    usageData[activeDomain] = (usageData[activeDomain] || 0) + elapsed;
    chrome.storage.local.set({ usageData });
  }
  startTime = Date.now();
}

// 탭 활성화 시
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  recordTime();

  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    activeTabId = activeInfo.tabId;
    activeDomain = extractDomain(tab.url);
    startTime = Date.now();
  } catch {
    activeTabId = null;
    activeDomain = null;
    startTime = null;
  }
});

// 탭 URL 변경 시
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === activeTabId && changeInfo.url) {
    recordTime();

    activeDomain = extractDomain(changeInfo.url);
    startTime = Date.now();
  }
});

// 창 포커스 변경 시
chrome.windows.onFocusChanged.addListener((windowId) => {
  recordTime();

  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    activeTabId = null;
    activeDomain = null;
    startTime = null;
  } else {
    chrome.tabs.query({ active: true, windowId }, (tabs) => {
      if (tabs.length > 0) {
        activeTabId = tabs[0].id;
        activeDomain = extractDomain(tabs[0].url);
        startTime = Date.now();
      } else {
        activeTabId = null;
        activeDomain = null;
        startTime = null;
      }
    });
  }
});

// 확장 프로그램 시작 시 저장된 데이터 불러오기
chrome.runtime.onStartup.addListener(() => {
  loadUsageData(() => {
    activeTabId = null;
    activeDomain = null;
    startTime = null;
  });
});

// 확장 프로그램 설치 시 초기화
chrome.runtime.onInstalled.addListener(() => {
  usageData = {};
  chrome.storage.local.set({ usageData });
});
